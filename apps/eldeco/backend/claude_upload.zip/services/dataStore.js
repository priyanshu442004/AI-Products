export const dataStore = {
  extracted: []
};
