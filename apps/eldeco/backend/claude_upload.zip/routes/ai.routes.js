import express from "express";
import multer from "multer";
import { handleSummaryReport, checkUploadStatus, uploadTrialBalance } from "../controllers/ai.controller.js";

const router = express.Router();

const storage = multer.diskStorage({
    destination: "uploads/",
    filename: (req, file, cb) => {
        cb(null, Date.now() + "-" + file.originalname);
    }
});
const upload = multer({ storage });

router.get("/status", checkUploadStatus);
router.post("/upload", upload.single("file"), uploadTrialBalance);
router.post("/send-summary", handleSummaryReport);



export default router;
